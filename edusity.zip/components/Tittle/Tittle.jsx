import React from 'react'
import './Tittle.css'

const Tittle = ({subTittle,tittle}) => {
  return (
    <div className='tittle'>
        <h2>{subTittle}</h2>
        <p>{tittle} </p>
    </div>
  )
}

export default Tittle