import React from 'react'
import './Contact.css'
import msg from '../../../assets/msg-icon.png'
import mail from '../../../assets/mail-icon.png'
import phone from '../../../assets/phone-icon.png'
import location from '../../../assets/location-icon.png'
import White from '../../../assets/white-arrow.png'

const Contact = () => {
  const [result, setResult] = React.useState("");

  const onSubmit = async (event) => {
    event.preventDefault();
    setResult("Sending....");
    const formData = new FormData(event.target);

    formData.append("access_key", "c4564755-25fc-4159-ada9-394d45ac36d2");

    const response = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (data.success) {
      setResult("Form Submitted Successfully");
      event.target.reset();
      event.setResult.reset();
    } 
    else {
      console.log("Error", data);
      setResult(data.message);
    }
  };
 return (
    <div className='contact'>
      <div className="column">
        <h3> Send Us a Message <img src={msg}  /></h3>
        <p> The page may also include a map of the college campus and links to social media profiles. A well-designed "Contact Us" page can help build trust with visitors, answer frequently asked questions, and provide a personalized experience for those interested in learning more about the college.</p>
        <ul>
          <li><img src={mail} className="icon" /> divya@email.com </li>
          <li> <img src={phone} className="icon" />+2 65465 78657</li >
          <li><img src={location} className="icon" /> 22/324, cuzzamindh lane, east Washington USA </li>
        </ul>
      </div>
      <div className="column">
        <form onSubmit={onSubmit} >
          <label >Your Name </label>
          <input type="text"  placeholder='Enter Your NAme' name='name'/>
          <label > Phone Number</label>
          <input type="tel" placeholder='Enter your phone number'name='number'/>
          <label > Write Your Message Here</label>
          <textarea name= "message" rows="6" placeholder='Write Your Mesage' required></textarea>
          <button className='dark-btn'> Submit <img src={White} alt="" /></button>
        </form>
        <span>{result}</span>
      </div>
    </div>
  )
}

export default Contact