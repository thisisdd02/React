import React from 'react'
import './Footer.css'

const Footer = () => {
  return ( 
    <div className='footer'>
         <p>@copyrights2024 Educity</p> 
         <ul>
            <li>Privacy Policy</li>
            <li>Terms And Conditions</li>
            
            </ul>  


        </div>
   )
}

export default Footer
