import React from 'react'
import'./About.css'
import about from '../../../assets/about.png'
import playIcon from '../../../assets/play-icon.png'

const About = () => {
  return (
    <div className='about'>
        <div className="aboutLeft">
        <img src={about} className="abouticon" />
        <img src={playIcon} className="playicon"/>
        </div>
        <div className="aboutRight">
            <h2> ABOUT OUR COLLEGE</h2>
            <p><span>A</span> college website is an essential tool for any higher education institution. It serves as a digital hub for students, faculty, and staff, as well as prospective students and their families. A college website can provide information about academic programs, campus life, admissions, and financial aid. It can also showcase the school's history, mission, and values.</p>
            <p> <span> A </span>well-designed college website can help a school stand out from the competition and make a positive impression on visitors. It can also improve the user experience by making it easy for visitors to find the information they need. Features such as clear navigation, search functionality, and mobile optimization can all contribute to a positive user experience.</p>
            <p> <span>O</span>verall, a college website is a vital tool for any higher education institution. It can help a school connect with its various audiences, provide valuable information, and enhance the user experience.</p>
        </div>
    </div>
  )
}

export default About