import React from 'react'
import './Hero.css'
import arrow from'../../../assets/dark-arrow.png'

const Hero = () => {
  return (
    <div className='hero'>
        <div className="heroText">
            <h2>Ensure the Education For Better World</h2>
            <p> Our College Provoid Some Different Level of Education 
                for Our Student Will Conqueor The World
            </p>
            <button className='btn'>Explore now <img src={arrow} alt="" /></button>
        </div>

    </div>
  )
}

export default Hero