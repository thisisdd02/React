import React, {  useState } from 'react'
import { Link, Button, Element, Events, animateScroll as scroll, scrollSpy } from 'react-scroll';
import './navbar.css'
import logo from '../../../assets/logo.png'
import menu from '../../../assets/menu-icon.png'


const Navbar = () => {
    const[sticky,setsticky]=useState(false);
    window.addEventListener('scroll', function() {
        if (window.scrollY > 500) {
            setsticky(true);
        } else {
            setsticky(false);
        }
      });
    const[mobileMenu,setmobileMenu]=useState(false);
    function toogleMenu() {
      mobileMenu?setmobileMenu(false):setmobileMenu(true)
    }

   
      return <>
    <nav className={`container ${sticky ? 'dark':''}`}>
      
    <img src={logo} alt="no"  className='logo'/>
    <ul className={mobileMenu?'':'hide-mobileMenu'}>
      <li> <Link to='hero' smooth={true} offset={0} duration={500}> Home</Link></li>
        <li> <Link to='program' smooth={true} offset={-260} duration={500}>Program</Link></li>
        <li><Link to='about' smooth={true} offset={-150} duration={500}>About </Link></li>
        <li> <Link to='campus' smooth={true} offset={-260} duration={500}>Campus</Link></li>
        <li><Link to='testimonials' smooth={true} offset={-260} duration={500}> Testimonials </Link></li>
        <li><Link to='contact' smooth={true} offset={-260} duration={500} className='btn'>Contact</Link></li>
    </ul>
    <img src={menu} className="menu"  onClick={toogleMenu}/>
  </nav>
  </>
   
  
}

export default Navbar