import React, { useState } from 'react'
import Navbar from './assets/components/navbar/navbar'
import Hero from './assets/components/hero/Hero'
import Program from './assets/components/program/Program'
import Tittle from './assets/components/Tittle/Tittle'
import About from './assets/components/about/About'
import Campus from './assets/components/campus/Campus'
import Testimonials from './assets/components/Testimonials/Testimonials'
import Contact from './assets/components/contact/Contact'
import Footer from './assets/components/footer/Footer'

const App = () => {
  const[Playstate,setPlaystate]= useState(false)

  return <>
      <Navbar/>
      <Hero/>
      <div className="container">
            <Tittle subTittle='OUR PROGRAM' tittle='What The Course We Offer'/>
             <Program/>
             <About setPlaystate={setPlaystate}/>
             <Tittle subTittle='OUR CAMPUS' tittle='College Gallery'/>
            <Campus/>
            <Tittle subTittle='TESTIMONIALS' tittle='What Our Student Says'/>
            <Testimonials/>
            <Tittle subTittle='CONTACT' tittle='Get In Touch'/>
            <Contact/>
            <Footer/>

      </div>
    </>
}

export default App